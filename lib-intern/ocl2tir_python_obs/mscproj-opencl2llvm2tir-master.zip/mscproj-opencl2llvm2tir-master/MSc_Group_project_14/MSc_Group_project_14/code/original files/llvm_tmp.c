// This file should containt the macros and definitions to make the kernel file work with LLVM
// OpenCL specific keywords and types should be removed or changed
// OpenCL API functions should be defined with a stub

// Macros

// ... your code here ...

// Stubs

// ... your code here ...

#include "llvm_tmp_.cl"
